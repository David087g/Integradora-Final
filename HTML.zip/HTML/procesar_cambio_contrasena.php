<?php
if (!isset($_POST['token']) || !isset($_POST['password'])) {
    echo 'Token o contraseña no proporcionados.';
    exit();
}

$token = $_POST['token'];
$newPassword = $_POST['password'];

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Consultar la base de datos para verificar el token y obtener el correo
$sql = "SELECT * FROM iniciodesesion WHERE reset_token = '$token' AND token_expiry > NOW()";
$resultado = mysqli_query($enlace, $sql);

if ($resultado && mysqli_num_rows($resultado) > 0) {
    // Obtener el correo asociado al token
    $fila = mysqli_fetch_assoc($resultado);
    $correo = $fila['Correo'];

    // Actualizar la contraseña en la base de datos
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $sqlUpdate = "UPDATE iniciodesesion SET Contraseña = '$hashedPassword', reset_token = NULL, token_expiry = NULL WHERE reset_token = '$token'";
    $resultadoUpdate = mysqli_query($enlace, $sqlUpdate);

    if ($resultadoUpdate) {
        echo"<script type='text/javascript'>alert('Contraseña Cambiada Correctamente, Inicia sesión');
        window.location.href = 'Pag1.html';
        </script>";
        exit();
    } else {
        echo 'Hubo un error al cambiar la contraseña.';
    }
} else {
    echo 'Token no válido o ha expirado.';
}

mysqli_close($enlace);
?>

