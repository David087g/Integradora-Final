<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$conn = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);


// Verificar si la conexión fue exitosa
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el ID del usuario de la sesión
$usuario_id = $_SESSION['usuario_id'];

// Obtener el ID de la huella a cancelar desde el formulario
$huella_id = $_POST['huella_id'];

// Consulta para eliminar la huella perdida
$consulta_eliminar = "DELETE FROM subirhuellasperdidas WHERE id = '$huella_id'";
if (mysqli_query($conn, $consulta_eliminar)) {
    echo "<script>alert('La huella perdida ha sido eliminada con éxito.'); window.location.href = 'AceptarHuellas.php'</script>";
} else {
    echo "Error al eliminar la huella perdida: " . mysqli_error($conn);
}

// Cerrar la conexión a la base de datos
mysqli_close($conn);
?>
