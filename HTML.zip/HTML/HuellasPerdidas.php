<?php
// Iniciar sesión
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$conn = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el ID del usuario de la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener el nombre del usuario y su foto de perfil
$consulta = "SELECT usuario, foto_perfil FROM iniciodesesion WHERE id = '$usuario_id'";
$resultado = mysqli_query($conn, $consulta);

// Verificar si se encontró el usuario
if ($resultado && mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    $nombre_usuario = $usuario['usuario'];
    $foto_perfil = $usuario['foto_perfil'];
} else {
    $nombre_usuario = "Usuario"; // Valor por defecto si no se encuentra el usuario
    $foto_perfil = null;
}

// Verificar si se ha enviado el formulario de aprobación
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['huella_id'])) {
    // Obtener el ID de la huella aprobada
    $huella_id = $_POST['huella_id'];
    
    // Actualizar el estado de aprobación en la base de datos
    $query_aprobar = "UPDATE subirhuellasperdidas SET aprobado = 1 WHERE id = $huella_id";
    
    // Ejecutar la consulta de actualización
    if (mysqli_query($conn, $query_aprobar)) {
        echo "<script>alert('Huellas perdidas aprobadas exitosamente.'); window.location.href = 'AceptarHuellas.php'</script>";
    } else {
        echo "Error al aprobar huella perdida: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Huellas Perdidas Aprobadas</title>
    <link rel="stylesheet" href="AceptarHuellas.css">
</head>
<body>

<header>
    <nav>
        <div class="nav-left">
            <img class="logo" src="../Imagenes/Logo.PNG" alt="Logo">
            <a href="Bienvenido.php" class="inicio" style="color: white;">INICIO</a>
        </div>
        <ul class="nav-right">
            <li><a href="HuellasPerdidas.php"><span class="icon">&#x1F4CD;</span> HUELLAS PERDIDAS</a></li>
            <li><a href="SubirHuellas.php"><span class="icon">&#x1F4E9;</span>SUBIR HUELLAS</a></li>
            <li><a href="Bienvenido.php"><span class="icon">&#x1F4D6;</span> CÓDIGO DE ÉTICA</a></li>
            <!--<li><a href="CerrarSesion.php"><span class="icon">&#x1F511;</span> CERRAR SESIÓN</a></li>-->
        </ul>
        <img src="<?php echo $foto_perfil ? 'data:image/jpeg;base64,' . base64_encode($foto_perfil) : '../Imagenes/user.png'; ?>" class="user-pic" onclick="toggleMenu()">

        <div class="sub-menu-wrap" id="subMenu">
            <div class="sub-menu">
                <div class="user-info">
                    <img src="<?php echo $foto_perfil ? 'data:image/jpeg;base64,' . base64_encode($foto_perfil) : '../Imagenes/user.png'; ?>" alt="">
                    <h2><?php echo htmlspecialchars($nombre_usuario); ?></h2>
                </div>
                <hr>
                <a href="editarPerfil.php" class="sub-menu-link">
                    <img src="../Imagenes/profile.png" alt="">
                    <p>Editar perfil</p>
                    <span>></span>
                </a>

                <a href="CerrarSesion.php" class="sub-menu-link">
                    <img src="../Imagenes/logout.png" alt="">
                    <p>Cerrar Sesión</p>
                    <span>></span>
                </a>
            </div>
        </div>
    </nav>
</header>
<br><br><br><br><br>
<main>
    <div class="contenedor-huellas">
        <h1 style="color:white;">Huellas Perdidas Aprobadas</h1>
        <h3>En este sitio podrás buscar y ayudar a encontrar mascotas perdidas dentro de tu localidad. Actualmente, abarcamos todos los municipios de Monterrey. Próximamente ampliaremos nuestros servicios para cubrir todos los municipios de Monterrey de manera organizada por secciones.</h3>
        <div id="selectContainer">
        <select id="municipiosSelect" name="municipios">
            <option value="apodaca">Apodaca</option>
            <option value="cadereyta">Cadereyta Jiménez</option>
            <option value="elcarmen">El Carmen</option>
            <option value="garcia">García</option>
            <option value="sanpedro">San Pedro Garza García</option>
            <option value="escobedo">General Escobedo</option>
            <option value="guadalupe">Guadalupe</option>
            <option value="juarez">Juárez</option>
            <option value="monterrey">Monterrey</option>
            <option value="salinas">Salinas Victoria</option>
            <option value="sanicolas">San Nicolás de los Garza</option>
            <option value="santacatarina">Santa Catarina</option>
            <option value="santiago">Santiago</option>
        </select>
        <button id="buscarBtn">Buscar</button>
        <p class="Advertencia"><-- Próximamente</p>
        </div>
        
        <?php
        // Consulta para obtener las huellas perdidas aprobadas
        $consulta_huellas_aprobadas = "SELECT * FROM subirhuellasperdidas WHERE aprobado = 1";
        $resultado_huellas_aprobadas = mysqli_query($conn, $consulta_huellas_aprobadas);
        
        if (mysqli_num_rows($resultado_huellas_aprobadas) > 0) {
            while ($huella = mysqli_fetch_assoc($resultado_huellas_aprobadas)) {
                echo "<div class='tarjeta'>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Nombre⬇</span>";
                echo "<span class='valor'>" . $huella['nombre'] . "</span>";
                echo "</div>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Raza⬇</span>";
                echo "<span class='valor'>" . $huella['raza'] . "</span>";
                echo "</div>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Color⬇</span>";
                echo "<span class='valor'>" . $huella['color'] . "</span>";
                echo "</div>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Último Lugar Visto⬇</span>";
                echo "<span class='valor'>" . $huella['lugar'] . "</span>";
                echo "</div>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Contacto y más datos sobre la mascota⬇</span>";
                echo "<span class='valor'>" . $huella['contacto'] . "</span>";
                echo "</div>";
                // Otros detalles de la huella perdida...
                
                echo "<div class='campo'>";
                echo "<span class='titulo'>Foto:</span>";
                echo "<div class='foto' onclick='openModal(\"data:image/jpeg;base64," . base64_encode($huella['foto']) . "\")'>";
                echo "<img src='data:image/jpeg;base64," . base64_encode($huella['foto']) . "' alt='Foto de la mascota'>";
                echo "<p>Foto</p>"; // Texto para centrar junto a la foto
                echo "</div>";
                echo "</div>";

                // Formulario para aprobar la huella perdida
                echo "</form>";

                echo "</div>";
            }
        } else {
            echo "<p>No hay huellas perdidas aprobadas.</p>";
        }
        ?>
    </div>
</main>
<footer id='pie'>
<p style="color: #fff;">&copy; 2024 Alonso Flores David Abraham. Matrícula 302310215. <br> Nicolás Gael Martínez Muños 302310208.</p>
</footer>

<!-- Modal para mostrar la imagen en grande -->
<div id="myModal" class="modal">
    <span class="close" onclick="closeModal()">&times;</span>
    <img class="modal-content" id="modalImg">
</div>

<script>
    let subMenu = document.getElementById("subMenu");
    function toggleMenu(){
        subMenu.classList.toggle("open-menu");
    }

    // Función para abrir el modal con la imagen en grande
    function openModal(imageSrc) {
        var modal = document.getElementById("myModal");
        var modalImg = document.getElementById("modalImg");
        modal.style.display = "block";
        modalImg.src = imageSrc;
    }

    // Función para cerrar el modal
    function closeModal() {
        var modal = document.getElementById("myModal");
        modal.style.display = "none";
    }
</script>

</body>
</html>

<?php
// Cerrar la conexión a la base de datos
mysqli_close($conn);
?>
