<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mascotas Perdidas</title>
    <style>
        .gallery {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            grid-gap: 20px;
            justify-items: center;
        }
        .gallery img {
            width: 100%;
            height: auto;
            max-height: 300px;
        }
    </style>
</head>
<body>
    <h1>Mascotas Perdidas</h1>
    <div class="gallery">
        <?php
        // Conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "integradora";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Consulta SQL para obtener las imágenes de mascotas perdidas
        $sql = "SELECT id, foto FROM subirhuellasperdidas";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Mostrar las imágenes
            while ($row = $result->fetch_assoc()) {
                $id = $row["id"];
                // Convertir los datos binarios de la imagen en formato base64
                $rutaImagen = base64_encode($row["foto"]);
                // Mostrar la imagen en la página web
                echo '<a href="detalle.php?id=' . $id . '"><img src="data:image/jpeg;base64,' . $rutaImagen . '" alt="Mascota perdida"></a>';
            }
        } else {
            echo "No se encontraron imágenes de mascotas perdidas.";
        }
        $conn->close();
        ?>
    </div>
</body>
</html>
