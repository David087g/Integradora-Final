<?php
// Funciones de validación
function validarNombre($nombre) {
    // Solo letras y espacios permitidos en el nombre
    return preg_match("/^[a-zA-Z\s]*$/", $nombre);
}

function validarTelefono($telefono) {
    // Formato de teléfono válido (solo números)
    return preg_match("/^[0-9]{10}$/", $telefono);
}

function validarCorreo($correo) {
    // Formato de correo electrónico válido
    return filter_var($correo, FILTER_VALIDATE_EMAIL);
}

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Inicializar variables para los mensajes de error
    $nombreError = $telefonoError = $correoError = $contraseñaError = "";

    // Validar el nombre
    if (empty($_POST["nombre"])) {
        $nombreError = "Nombre es requerido";
    } else {
        $nombre = $_POST["nombre"];
        if (!validarNombre($nombre)) {
            $nombreError = "Formato de nombre inválido";
        }
    }

    // Validar el teléfono
    if (empty($_POST["phone"])) {
        $telefonoError = "Teléfono es requerido";
    } else {
        $telefono = $_POST["phone"];
        if (!validarTelefono($telefono)) {
            $telefonoError = "Formato de teléfono inválido";
        }
    }

    // Validar el correo electrónico
    if (empty($_POST["email"])) {
        $correoError = "Correo electrónico es requerido";
    } else {
        $correo = $_POST["email"];
        if (!validarCorreo($correo)) {
            $correoError = "Formato de correo electrónico inválido";
        } else {
            // Verificar si el correo ya existe en la base de datos
            $Servidor = "localhost";
            $Usuario = "root";
            $Contraseña = "";
            $BaseDeDatos = "integradora";

            $enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

            // Consulta para verificar si el correo ya está en la base de datos
            $consulta = "SELECT * FROM iniciodesesion WHERE Correo = '$correo'";
            $resultado = mysqli_query($enlace, $consulta);

            // Verificar si se encontró algún resultado
            if (mysqli_num_rows($resultado) > 0) {
                $correoError = "El correo electrónico ya está registrado";
                echo "<script>alert('El correo electrónico ya está registrado'); window.location.href = 'crearCuenta.html';</script>";
                // Redirigir al usuario a crearCuenta.html y salir del script
                exit;
            }

            // Cerrar la conexión
            mysqli_close($enlace);
        }
    }

    // Validar la contraseña
    if (empty($_POST["password"])) {
        $contraseñaError = "Contraseña es requerida";
    } else {
        $contraseña = $_POST["password"];
        $hashedPassword = password_hash($contraseña, PASSWORD_DEFAULT); // Hashear la contraseña
    }

    // Si hay algún error de validación, no continuar
    if (!empty($nombreError) || !empty($telefonoError) || !empty($correoError) || !empty($contraseñaError)) {
        echo "Por favor, corrige los errores del formulario: <br>";
        echo $nombreError . "<br>";
        echo $telefonoError . "<br>";
        echo $correoError . "<br>";
        echo $contraseñaError . "<br>";
        exit;
    }

    // Conexión a la base de datos
    $enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

    // Verificar la conexión
    if (!$enlace) {
        die("Error de conexión: " . mysqli_connect_error());
    } 

    // Inserción de datos en la base de datos
    $insertarDatos = "INSERT INTO iniciodesesion (Usuario, Telefono, Correo, Contraseña) VALUES ('$nombre', '$telefono', '$correo', '$hashedPassword')";

    $ejecutarInsertar = mysqli_query($enlace, $insertarDatos);

    if ($ejecutarInsertar) {
        echo "<script type='text/javascript'>alert('Haz creado la cuenta correctamente.');</script>";
        header("Location: inicioSeccion1.html");
        exit;
    } else {
        echo "Error en la inserción: " . mysqli_error($enlace);
    }

    // Cerrar la conexión
    mysqli_close($enlace);
}
?>
