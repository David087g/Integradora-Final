<?php
// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el token del formulario
$token = $_POST['token'];

// Consultar la base de datos para verificar si el token es válido y no ha expirado
$sql = "SELECT * FROM iniciodesesion WHERE reset_token = '$token' AND token_expiry > NOW()";
$resultado = mysqli_query($enlace, $sql);

if ($resultado && mysqli_num_rows($resultado) > 0) {
    // Redirigir al formulario de cambio de contraseña con el token
    header("Location: Ccontraseña2.php?token=$token");
    exit();
} else {
    echo "<script type='text/javascript'>alert('El token Ha Expirado o No Es El Correcto');
        window.location.href = 'ingresar_token.html';
        </script>";
}

// Cerrar la conexión
mysqli_close($enlace);
?>
