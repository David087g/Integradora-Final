<?php
// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Iniciar sesión
session_start();

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['email'];
    $contraseña = $_POST['password'];

    // Validar los datos ingresados
    if (!empty($correo) && !empty($contraseña)) {
        // Protegerse contra inyecciones SQL
        $correo = mysqli_real_escape_string($enlace, $correo);

        // Verificar si es el administrador
        if ($correo === 'ADMIN@gmail.com' && $contraseña === 'DAVID') {
            $_SESSION['usuario_id'] = 'admin';
            $_SESSION['usuario_correo'] = $correo;

            // Redirigir a la página de administrador
            header("Location: Admin.php");
            exit;
        }

        // Consulta para obtener el usuario con el correo proporcionado
        $consulta = "SELECT * FROM iniciodesesion WHERE Correo = '$correo'";
        $resultado = mysqli_query($enlace, $consulta);

        // Verificar si se encontró algún resultado
        if (mysqli_num_rows($resultado) > 0) {
            $usuario = mysqli_fetch_assoc($resultado);

            // Verificar la contraseña
            if (password_verify($contraseña, $usuario['Contraseña'])) {
                // Iniciar la sesión del usuario
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_correo'] = $usuario['Correo'];

                // Redirigir a la página de bienvenida o dashboard
                header("Location: Bienvenido.php");
                exit;
            } else {
                // Contraseña incorrecta
                header("Location: inicioSeccion1.html?error=Correo o contraseña incorrectos.");
                exit;
            }
        } else {
            // Usuario no encontrado
            header("Location: inicioSeccion1.html?error=Correo o contraseña incorrectos.");
            exit;
        }
    } else {
        // Datos faltantes
        header("Location: inicioSeccion1.html?error=Correo o contraseña incorrectos.");
        exit;
    }
}

// Cerrar la conexión
mysqli_close($enlace);
?>
