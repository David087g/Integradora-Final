<?php
// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Función para generar un token único
function generar_token() {
    // Generar un token único
    $token = md5(uniqid(rand(), true));
    return $token;
}

// Obtener el correo del formulario
$email = $_POST['email'];

// Generar un token único
$token = generar_token();

// Actualizar la tabla de usuarios con el token y el tiempo de expiración
$expiry = date("Y-m-d H:i:s", strtotime('+1 hour')); // Expira en 1 hora
$sql = "UPDATE iniciodesesion SET reset_token = '$token', token_expiry = '$expiry' WHERE Correo = '$email'";
$resultado = mysqli_query($enlace, $sql);

if ($resultado) {
    // Envío de correo electrónico
    $resetLink = "http://localhost/practica/HTML/ingresar_token.html"; // Modifica la URL

    $to = $email;
    $subject = 'Recuperación de contraseña';
    
    $message = '
    <html>
    <head>
        <title>Recuperación de contraseña</title>
        <style>
            .email-container {
                width: 100%;
                padding: 20px;
                background-color: #f4f4f4;
                font-family: Arial, sans-serif;
            }
            .email-header {
                background-color: #007BFF;
                color: white;
                padding: 10px;
                text-align: center;
                font-size: 24px;
            }
            .email-body {
                background-color: white;
                padding: 20px;
                margin: 10px 0;
                border: 1px solid #ddd;
                border-radius: 5px;
            }
            .email-footer {
                text-align: center;
                color: #666;
                font-size: 14px;
                margin-top: 10px;
            }
            .reset-button {
                display: inline-block;
                padding: 10px 20px;
                margin: 20px 0;
                background-color: #007BFF;
                color: white;
                text-decoration: none;
                border-radius: 5px;
            }
            .reset-button:hover {
                background-color: #0056b3;
            }
            .email-title {
                font-size: 30px;
                font-weight: bold;
                text-align: center;
                color: #333;
                margin-bottom: 20px;
            }
            .email-image {
                display: block;
                margin: 0 auto;
                width:300px;
                height: auto;
            }
        </style>
    </head>
    <body>
        <div class="email-container">
            <div class="email-header">
                Recuperación de contraseña
            </div>
            <div class="email-body">
                <h1 class="email-title">Huellas perdidas</h1>
                <img class="email-image" src="http://localhost/Practica/Imagenes/Logo.png" alt="Huellas perdidas">
                <p>Hola,</p>
                <p>Haz clic en el siguiente enlace para ingresar tu token y restablecer tu contraseña:</p>
                <a class="reset-button" href="' . $resetLink . '">Restablecer contraseña</a>
                <p>Tu token es: <strong>' . $token . '</strong></p>
            </div>
            <div class="email-footer">
                <p>Si no solicitaste restablecer tu contraseña, por favor ignora este correo.</p>
            </div>
        </div>
    </body>
    </html>';

    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: tu_correo@example.com' . "\r\n"; // Tu correo personal

    if (mail($to, $subject, $message, $headers)) {
        echo "<script type='text/javascript'>alert('Reporte enviado exitosamente. Revisa tu correo');
        window.location.href = 'olvide_contraseña.html';
        </script>";
    } else {
        echo 'Hubo un error al enviar el correo.';
    }
} else {
    echo 'Hubo un error al procesar la solicitud.';
}

// Cerrar la conexión
mysqli_close($enlace);
?>
