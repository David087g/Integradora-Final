<?php
session_start();
session_destroy();
header("Location: inicioSeccion1.html");
exit;
?>
