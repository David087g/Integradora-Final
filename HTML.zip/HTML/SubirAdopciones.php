<?php
// Iniciar sesión
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el ID del usuario de la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener el nombre del usuario
$consulta = "SELECT usuario FROM iniciodesesion WHERE id = '$usuario_id'";
$resultado = mysqli_query($enlace, $consulta);

// Verificar si se encontró el usuario
if ($resultado && mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    $nombre_usuario = $usuario['usuario'];
} else {
    $nombre_usuario = "Usuario"; // Valor por defecto si no se encuentra el usuario
}

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $especie = $_POST['especie'];
    $raza = $_POST['raza'];
    $edad = $_POST['edad'];
    $sexo = $_POST['sexo'];
    $tamaño = $_POST['tamaño'];
    $color = $_POST['color'];
    $descripcion = $_POST['descripcion'];
    $ubicacion = $_POST['ubicacion'];
    $contacto = $_POST['contacto'];
    $aprobado = 0; // Inicialmente no aprobado

    // Manejar la subida de la foto
    $imagen = $_FILES['imagen'];
    $imagenTmpNombre = $imagen['tmp_name'];

    // Verificar que se haya seleccionado una imagen
    if (!empty($imagenTmpNombre)) {
        // Leer el contenido de la imagen
        $contenidoImagen = file_get_contents($imagenTmpNombre);
    } else {
        die("Error: No se ha seleccionado ninguna imagen.");
    }

    // Consulta para insertar los datos en la tabla adopciones
    $insertarDatos = "INSERT INTO adopciones (nombre, especie, raza, edad, sexo, tamaño, color, descripcion, ubicacion, contacto, imagen, aprobado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Preparar la consulta
    $stmt = mysqli_prepare($enlace, $insertarDatos);

    // Vincular parámetros a la consulta
    mysqli_stmt_bind_param($stmt, "sssisssssssi", $nombre, $especie, $raza, $edad, $sexo, $tamaño, $color, $descripcion, $ubicacion, $contacto, $contenidoImagen, $aprobado);

    // Ejecutar la consulta
    if (mysqli_stmt_execute($stmt)) {
        echo "<script type='text/javascript'>alert('Mascota registrada para adopción correctamente.');</script>";
    } else {
        echo "Error al insertar los datos: " . mysqli_error($enlace);
    }

    // Cerrar la consulta
    mysqli_stmt_close($stmt);
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="SubirHuellas.css">
    <title>Registrar Mascota para Adopción</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav-left">
                <img class="logo" src="../Imagenes/Logo.PNG" alt="Logo">
                <a href="Bienvenido.php" class="inicio" style="color: white;">INICIO</a>
            </div>
            <ul class="nav-right">
                <li><a href="HuellasPerdidas.php"><span class="icon">&#x1F4CD;</span> HUELLAS PERDIDAS</a></li>
                <li><a href="SubirHuellas.php"><span class="icon">&#x1F4E9;</span> SUBIR HUELLAS</a></li>
                <li><a href="SubirAdopciones.php"><span class="icon">&#x1F4D6;</span> ADOPTA</a></li>
                <li><a href="#"><span class="icon">&#x1F4D6;</span> CODIGO DE ETICA</a></li>
            </ul>
            <img src="../Imagenes/user.png" class="user-pic" onclick="toggleMenu()">

            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="../Imagenes/user.png" alt="">
                        <h2><?php echo htmlspecialchars($nombre_usuario); ?></h2>
                    </div>
                    <hr>
                    <a href="editarPerfil.php" class="sub-menu-link">
                        <img src="../Imagenes/profile.png" alt="">
                        <p>Editar perfil</p>
                        <span>></span>
                    </a>

                    <a href="CerrarSesion.php" class="sub-menu-link">
                        <img src="../Imagenes/logout.png" alt="">
                        <p>Cerrar Sesión</p>
                        <span>></span>
                    </a>
                </div>
            </div>
        </nav>
    </header>

    <div class="mainer">
        <div class="form-video-container">
            <div class="form-container">
                <main>
                    <form action="SubirAdopciones.php" method="POST" enctype="multipart/form-data">
                        <h2>REGISTRAR MASCOTA PARA ADOPCIÓN</h2>
                        <label for="nombre">Nombre de la Mascota:</label>
                        <input type="text" id="nombre" name="nombre" required>
                        
                        <label for="especie">Especie:</label>
                        <input type="text" id="especie" name="especie" required>
                        
                        <label for="raza">Raza:</label>
                        <input type="text" id="raza" name="raza" required>
                        
                        <label for="edad">Edad:</label>
                        <input type="number" id="edad" name="edad" required>
                        
                        <label for="sexo">Sexo:</label>
                        <input type="text" id="sexo" name="sexo" required>
                        
                        <label for="tamaño">Tamaño:</label>
                        <input type="text" id="tamaño" name="tamaño" required>
                        
                        <label for="color">Color:</label>
                        <input type="text" id="color" name="color" required>
                        
                        <label for="descripcion">Descripción:</label>
                        <textarea id="descripcion" name="descripcion" required></textarea>
                        
                        <label for="ubicacion">Ubicación:</label>
                        <select id="ubicacion" name="ubicacion" required>
                            <option value="apodaca">Apodaca</option>
                            <option value="cadereyta">Cadereyta Jiménez</option>
                            <option value="elcarmen">El Carmen</option>
                            <option value="garcia">García</option>
                            <option value="sanpedro">San Pedro Garza García</option>
                            <option value="escobedo">General Escobedo</option>
                            <option value="guadalupe">Guadalupe</option>
                            <option value="juarez">Juárez</option>
                            <option value="monterrey">Monterrey</option>
                            <option value="salinas">Salinas Victoria</option>
                            <option value="sanicolas">San Nicolás de los Garza</option>
                            <option value="santacatarina">Santa Catarina</option>
                            <option value="santiago">Santiago</option>
                        </select>
                        
                        <label for="imagen">Foto de la Mascota:</label>
                        <input type="file" id="imagen" name="imagen" accept="image/*" required>
                        
                        <label for="contacto">Datos de Contacto:</label>
                        <textarea id="contacto" name="contacto" required></textarea>
                    
                        <input type="submit" value="Registrar Mascota" class="btn">
                    </form>
                </main>
            </div>
            <div class="Video">
                <h2>Video Explicativo</h2>
                <video src="../Videos/SubirAdopciones.mp4" controls></video>
            </div>
        </div>
    </div>
    
    <footer id="pie">
    <p style="color: #fff;">&copy; 2024 Alonso Flores David Abraham. Matricula 302310215. <br> Nicolas Gael Martinez Muños 302310208.</p>
    </footer>
    
    <script>
        let subMenu = document.getElementById("subMenu");
        function toggleMenu(){
            subMenu.classList.toggle("open-menu");
        }
    </script>
</body>
</html>

<?php 
// Cerrar la conexión
mysqli_close($enlace);
?>