<?php
// Iniciar sesión
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el ID del usuario de la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener el nombre del usuario
$consulta = "SELECT usuario FROM iniciodesesion WHERE id = '$usuario_id'";
$resultado = mysqli_query($enlace, $consulta);

// Verificar si se encontró el usuario
if ($resultado && mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    $nombre_usuario = $usuario['ADMIN'];
} else {
    $nombre_usuario = "ADMIN"; // Valor por defecto si no se encuentra el usuario
}

// Cerrar la conexión
mysqli_close($enlace);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="BienvenidoCssPhp.css">
    <title>Bienvenido</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav-left">
                <img class="logo" src="../Imagenes/Logo.PNG" alt="Logo">
                <a href="Pag1.html" class="inicio" style="color: white;">INICIO</a>
            </div>
            <ul class="nav-right">
                <li><a href="AceptarHuellas.php"><span class="icon">&#x1F4E9;</span> ACEPTAR HUELLAS</a></li>
                <li><a href="CancelarHuellasPerdidas.php"><span class="icon">&#x1F4D6;</span>CANCELAR HUELLAS</a></li>
                <li><a href="ADMIN.php"><span class="icon">&#x1F4D6;</span> CODIGO DE ETICA</a></li>
                <!--<li><a href="CerrarSesion.php"><span class="icon">&#x1F511;</span> CERRAR SESION</a></li>-->
            </ul>
            <img src="../Imagenes/David.jpg" class="user-pic" onclick="toggleMenu()">

            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="../Imagenes/David.jpg" alt="">
                        <h2><?php echo htmlspecialchars($nombre_usuario); ?></h2>
                    </div>
                    <hr>

                    <a href="CerrarSesion.php" class="sub-menu-link">
                        <img src="../Imagenes/logout.png" alt="">
                        <p>Cerrar Sesión</p>
                        <span>></span>
                    </a>
                </div>
            </div>
        </nav>
    </header>
    <div class="imgYtexto">
        <div class="perroPlaya">
        <img src="../Imagenes/PerroPlaya.png" alt="">
        </div>
            <div class="Texto">
            <h1>Bienvenid@ Administrador</h1> 
            <p>

A nuestro buscador de huellas! Queremos guiarte en el uso de nuestra página para que puedas sacarle el máximo provecho: <br><br>

1. <b>Menú de Navegación</b>: Nuestro menú se encuentra ubicado en la parte superior, justo en el centro. Simplemente haz clic en cualquier opción del menú y te llevará a la página correspondiente. <br><br>

2. <b>Huellas Perdidas</b>: En esta sección, encontrarás información detallada sobre las mascotas que están perdidas. Te ayudaremos a difundir su búsqueda para que puedan reunirse con sus familias.<br><br>

3. <b> Huellas</b>: ¿Tienes una mascota perdida? Aquí podrás subir su información. Cuéntanos detalles como el último lugar donde fue vista, su color de pelo, nombre, raza y más. ¡Cada detalle cuenta!<br><br>

4. <b>Adopta</b>: En esta sección, podrás descubrir a las mascotas que están buscando un hogar amoroso. ¡Quizás encuentres a tu próximo compañero peludo aquí!<br><br>

5. <b>Código de Ética</b>: ¿Quieres volver a esta página? No te preocupes, el enlace al Código de Ética se encuentra justo debajo. Simplemente haz clic en él para regresar aquí en cualquier momento.<br><br>

¡Esperamos que disfrutes usando nuestra página y que encuentres la información que necesitas para ayudar a las mascotas perdidas y encontrar tu próxima mascota adoptiva!<br><br>
</p>
            </div>
    </div>
    <hr class="elhr">
    <div class="CodigoEtica">
    <p>

<h2>Código de Ética</h2>

En Huellas perdidas, nos comprometemos a fomentar un entorno en línea seguro, amigable y respetuoso para todos nuestros usuarios. Nuestro código de ética se basa en los siguientes principios: <br> <br>

1.<b>Respeto y Tolerancia</b>: Valoramos la diversidad y respetamos las opiniones y experiencias de todos los usuarios. No toleramos ningún tipo de discriminación, acoso o comportamiento irrespetuoso. <br> <br>

2.<b>Veracidad y Transparencia</b>: Nos esforzamos por proporcionar información precisa y verificada en todas nuestras secciones. Nos comprometemos a ser transparentes sobre nuestros procesos y políticas.<br> <br>

3.<b>Protección de la Privacidad</b>: Respetamos la privacidad de nuestros usuarios y nos comprometemos a proteger sus datos personales. Nunca compartiremos información confidencial sin consentimiento explícito.<br> <br>

4.<b>Filtro Administrativo</b>: Para garantizar la calidad y la idoneidad de las publicaciones en nuestra plataforma, contamos con un equipo administrativo que revisará y aprobará todas las búsquedas antes de ser publicadas. Nos reservamos el derecho de rechazar cualquier búsqueda que consideremos inapropiada o que viole nuestros términos de uso.<br> <br>

5.<b>Uso Responsable de la Plataforma</b>: Todos los usuarios son responsables de su comportamiento en nuestra plataforma. No toleramos el uso indebido de la misma para actividades ilegales, fraudulentas o perjudiciales.<br> <br>

6.<b>Colaboración y Apoyo</b>: Fomentamos la colaboración y el apoyo mutuo entre los usuarios. Promovemos un ambiente de solidaridad donde los usuarios puedan compartir recursos, información y experiencias de manera constructiva.<br> <br>

7.<b>Cumplimiento de las Normativas</b>: Nos comprometemos a cumplir con todas las leyes y regulaciones aplicables en todas las jurisdicciones donde operamos.<br> <br>

8.<b>Mejora Continua</b>: Estamos comprometidos con la mejora continua de nuestra plataforma y servicios. Valoramos los comentarios de nuestros usuarios y nos esforzamos por implementar mejoras que satisfagan sus necesidades.<br> <br>

Al utilizar Huellas perdidas, aceptas adherirte a nuestro código de ética y comprometerte a respetar estos principios en todo momento.<br> <br>

    </p>
    </div>
    <footer id="pie">
        <p style="color: #fff;">&copy; 2024 Alonso Flores David Abraham. Matricula 302310215.</p>
    </footer>
    <script>
        let subMenu = document.getElementById("subMenu");
        function toggleMenu(){
            subMenu.classList.toggle("open-menu");
        }
    </script>
</body>
</html>
