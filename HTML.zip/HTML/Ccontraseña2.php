<?php
if (!isset($_GET['token'])) {
    echo 'Token no proporcionado.';
    exit();
}

$token = $_GET['token'];

// Verificar el token en la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

$sql = "SELECT * FROM iniciodesesion WHERE reset_token = '$token' AND token_expiry > NOW()";
$resultado = mysqli_query($enlace, $sql);

if (!$resultado || mysqli_num_rows($resultado) == 0) {
    echo 'Token no válido o ha expirado.';
    mysqli_close($enlace);
    exit();
}

mysqli_close($enlace);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Ccontraseña2.css">
    <title>Cambio De Contraseña</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav-left">
                <img class="logo" src="../Imagenes/Logo.PNG" alt="Logo">
                <a href="Pag1.html" class="inicio">INICIO</a>
            </div>
        </nav>
    </header>

    <img class="back" src="../Imagenes/backgroundDog1.jpg" alt="">
    <br><br><br><br><br><br>

    <div class="body2">
        <form action="procesar_cambio_contrasena.php" method="post">
            <h2>Cambio De Contraseña</h2>
            <p>Ingresa los datos solicitados</p>
            <div class="input-group">
                <label for="password">Ingresa una nueva contraseña</label>
                <input type="password" name="password" placeholder="Contraseña" id="password" required>
                <input type="hidden" name="token" value="<?php echo $token; ?>">
                <input type="submit" value="Enviar">
            </div>
        </form>
    </div>
    <br><br><br><br><br>
</body>
</html>
