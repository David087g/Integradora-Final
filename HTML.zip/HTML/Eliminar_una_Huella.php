<?php
// Iniciar sesión si no lo está ya
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$conn = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Verificar si se ha enviado el formulario de borrar individualmente
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['huella_id'])) {
    // Obtener el ID de la huella a borrar
    $huella_id = $_POST['huella_id'];
    
    // Borrar el registro de la base de datos
    $query_borrar = "DELETE FROM subirhuellasperdidas WHERE id = ?";
    
    // Preparar la declaración
    $stmt = mysqli_prepare($conn, $query_borrar);
    if ($stmt === false) {
        echo "Error al preparar la consulta de borrado: " . mysqli_error($conn);
    } else {
        // Vincular parámetros
        mysqli_stmt_bind_param($stmt, "i", $huella_id);

        // Ejecutar la consulta de borrado
        if (mysqli_stmt_execute($stmt)) {
            echo "<script type='text/javascript'>
                    alert('Huella perdida borrada exitosamente.');
                    window.location.href = 'CancelarHuellasPerdidas.php';
                  </script>";
        } else {
            echo "Error al borrar huella perdida: " . mysqli_stmt_error($stmt);
        }

        // Cerrar la declaración
        mysqli_stmt_close($stmt);
    }
}

// Cerrar la conexión a la base de datos
mysqli_close($conn);
?>
