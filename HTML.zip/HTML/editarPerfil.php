<?php
// Iniciar sesión
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el ID del usuario de la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener la información del perfil del usuario
$consulta = "SELECT Usuario, Telefono, Correo, foto_perfil FROM iniciodesesion WHERE id = '$usuario_id'";
$resultado = mysqli_query($enlace, $consulta);

// Verificar si se encontró el usuario
if ($resultado && mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    $nombre_usuario = $usuario['Usuario'];
    $telefono = $usuario['Telefono'];
    $correo = $usuario['Correo'];
    $foto_perfil = $usuario['foto_perfil'];
} else {
    // Si no se encuentra el usuario, redirigir o mostrar un mensaje de error
    die("Usuario no encontrado");
}

// Procesar el formulario cuando se envíe
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Actualizar nombre, teléfono y correo
    $nuevo_nombre = $_POST['nombre'];
    $nuevo_telefono = $_POST['telefono'];
    $nuevo_correo = $_POST['correo'];

    $sql = "UPDATE iniciodesesion SET Usuario='$nuevo_nombre', Telefono='$nuevo_telefono', Correo='$nuevo_correo' WHERE id='$usuario_id'";
    mysqli_query($enlace, $sql);

    // Procesar la imagen de perfil si se sube una
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $image = file_get_contents($_FILES['profile_pic']['tmp_name']);

        // Convertir a binario
        $image_data = addslashes($image);

        // Actualizar la base de datos con la nueva imagen
        $sql = "UPDATE iniciodesesion SET foto_perfil='$image_data' WHERE id='$usuario_id'";
        mysqli_query($enlace, $sql);
    }

    // Redirigir a la página de bienvenida después de actualizar el perfil
    header("Location: Bienvenido.php");
    exit;
}

// Cerrar la conexión
mysqli_close($enlace);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="editarPerfil.css">
</head>
<body><header>
        <nav>
            <div class="nav-left">
                <img class="logo" src="../Imagenes/Logo.PNG" alt="Logo">
                <a href="Pag1.html" class="inicio" style="color: white;">INICIO</a>
            </div>
            <ul class="nav-right">
                <li><a href="HuellasPerdidas.php"><span class="icon">&#x1F4CD;</span> HUELLAS PERDIDAS</a></li>
                <li><a href="SubirHuellas.php"><span class="icon">&#x1F4E9;</span> SUBIR HUELLAS</a></li>
                <li><a href="Bienvenido.php"><span class="icon">&#x1F4D6;</span> CÓDIGO DE ÉTICA</a></li>
            </ul>
            <!-- Mostrar la imagen de perfil o una predeterminada -->
            <img src="<?php echo $foto_perfil ? 'data:image/jpeg;base64,' . base64_encode($foto_perfil) : '../Imagenes/user.png'; ?>" class="user-pic" onclick="toggleMenu()">

            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="<?php echo $foto_perfil ? 'data:image/jpeg;base64,' . base64_encode($foto_perfil) : '../Imagenes/user.png'; ?>" alt="">
                        <h2><?php echo htmlspecialchars($nombre_usuario); ?></h2>
                    </div>
                    <hr>
                    <a href="editarPerfil.php" class="sub-menu-link">
                        <img src="../Imagenes/profile.png" alt="">
                        <p>Editar perfil</p>
                        <span>></span>
                    </a>

                    <a href="CerrarSesion.php" class="sub-menu-link">
                        <img src="../Imagenes/logout.png" alt="">
                        <p>Cerrar Sesión</p>
                        <span>></span>
                    </a>
                </div>
            </div>
        </nav>
    </header>
    <div class="profile-container">
        <h2>Editar Perfil</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="profile-pic">
                <input type="file" id="file" name="profile_pic" accept="image/*" hidden>
                <label for="file" id="uploadBtn">
                    <img src="data:image/jpeg;base64,<?php echo base64_encode($foto_perfil); ?>" alt="Profile Picture" id="profileDisplay">
                    <div class="overlay">
                        <div class="text">Cambiar imagen</div>
                    </div>
                </label>
            </div>
            <div class="form-group">
                <label for="nombre" style="color:black;">Nombre:</label>
                <input type="text" name="nombre" id="nombre" value="<?php echo htmlspecialchars($nombre_usuario); ?>" required>
            </div>
            <div class="form-group">
                <label for="telefono" style="color:black;" >Teléfono:</label>
                <input type="text" name="telefono" id="telefono" value="<?php echo htmlspecialchars($telefono); ?>" required>
            </div>
            <div class="form-group">
                <label for="correo" style="color:black;">Correo:</label>
                <input type="email" name="correo" id="correo" value="<?php echo htmlspecialchars($correo); ?>" readonly>
            </div>
            <button type="submit">Guardar Cambios</button>
        </form>
    </div>
    <script src="editarPerfil.js"></script>
    <script>
        let subMenu = document.getElementById("subMenu");
        function toggleMenu(){
            subMenu.classList.toggle("open-menu");
        }
    </script>

</body>
</html>

