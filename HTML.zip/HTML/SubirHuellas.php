<?php
// Iniciar sesión
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el ID del usuario de la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener el nombre del usuario y su foto de perfil
$consulta = "SELECT usuario, foto_perfil FROM iniciodesesion WHERE id = '$usuario_id'";
$resultado = mysqli_query($enlace, $consulta);

// Verificar si se encontró el usuario
if ($resultado && mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    $nombre_usuario = $usuario['usuario'];
    $foto_perfil = $usuario['foto_perfil'];
} else {
    $nombre_usuario = "Usuario"; // Valor por defecto si no se encuentra el usuario
    $foto_perfil = null;
}

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $raza = $_POST['raza'];
    $color = $_POST['color'];
    $lugar = $_POST['lugar'];
    $contacto = $_POST['contacto'];
    $aprobado = 0; // Inicialmente no aprobado

    // Manejar la subida de la foto
    $foto = $_FILES['foto'];
    $fotoTmpNombre = $foto['tmp_name'];

    // Leer el contenido de la foto
    $contenidoFoto = file_get_contents($fotoTmpNombre);

    // Consulta para insertar los datos en la tabla
    $insertarDatos = "INSERT INTO subirhuellasperdidas (nombre, raza, color, lugar, contacto, foto, aprobado) VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Preparar la consulta
    $stmt = mysqli_prepare($enlace, $insertarDatos);

    // Vincular parámetros a la consulta
    mysqli_stmt_bind_param($stmt, "ssssssi", $nombre, $raza, $color, $lugar, $contacto, $contenidoFoto, $aprobado);

    // Ejecutar la consulta
    if (mysqli_stmt_execute($stmt)) {
        echo "<script type='text/javascript'>alert('Reporte enviado exitosamente.');</script>";
    } else {
        echo "Error al insertar los datos: " . mysqli_error($enlace);
    }

    // Cerrar la consulta
    mysqli_stmt_close($stmt);
}

// Cerrar la conexión
mysqli_close($enlace);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="SubirHuellas.css">
    <title>Subir Huellas</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav-left">
                <img class="logo" src="../Imagenes/Logo.PNG" alt="Logo">
                <a href="Bienvenido.php" class="inicio" style="color: white;">INICIO</a>
            </div>
            <ul class="nav-right">
                <li><a href="HuellasPerdidas.php"><span class="icon">&#x1F4CD;</span> HUELLAS PERDIDAS</a></li>
                <li><a href="SubirHuellas.php"><span class="icon">&#x1F4E9;</span> SUBIR HUELLAS</a></li>
                <li><a href="Bienvenido.php"><span class="icon">&#x1F4D6;</span> CÓDIGO DE ÉTICA</a></li>
            </ul>
            <img src="<?php echo $foto_perfil ? 'data:image/jpeg;base64,' . base64_encode($foto_perfil) : '../Imagenes/user.png'; ?>" class="user-pic" onclick="toggleMenu()">

            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="<?php echo $foto_perfil ? 'data:image/jpeg;base64,' . base64_encode($foto_perfil) : '../Imagenes/user.png'; ?>" alt="">
                        <h2><?php echo htmlspecialchars($nombre_usuario); ?></h2>
                    </div>
                    <hr>
                    <a href="editarPerfil.php" class="sub-menu-link">
                        <img src="../Imagenes/profile.png" alt="">
                        <p>Editar perfil</p>
                        <span>></span>
                    </a>

                    <a href="CerrarSesion.php" class="sub-menu-link">
                        <img src="../Imagenes/logout.png" alt="">
                        <p>Cerrar Sesión</p>
                        <span>></span>
                    </a>
                </div>
            </div>
        </nav>
    </header>

    <div class="mainer">
        <div class="form-video-container">
            <div class="form-container">
            <main>
                <form action="SubirHuellas.php" method="POST" enctype="multipart/form-data">
                <h2>REPORTAR MASCOTA PERDIDA</h2> <!-- Movido aquí -->
                <label for="nombre">Nombre de la Mascota:</label>
                <input type="text" id="nombre" name="nombre" required>
                
                <label for="raza">Raza:</label>
                <input type="text" id="raza" name="raza" required>
                
                <label for="color">Color:</label>
                <input type="text" id="color" name="color" required>
                
                <label for="lugar">Último Lugar Visto:</label>
                <input type="text" id="lugar" name="lugar" required>
                
                <label for="foto">Foto de la Mascota:</label>
                <input type="file" id="foto" name="foto" accept="image/*" required>
                
                <label for="contacto">Datos de Contacto (También puedes especificar más cosas de la mascota):</label>
                <textarea id="contacto" name="contacto" required></textarea>
            
                <input type="submit" value="Reportar Mascota" class="btn">
                </form>
            </main>

            </div>
            <div class="Video">
                <h2>Video Explicativo</h2>
                <video src="../Videos/SubirHuellas.mp4" controls></video>
            </div>
        </div>
    </div>
    
    <footer id="pie">
    <p style="color: #fff;">&copy; 2024 Alonso Flores David Abraham. Matrícula 302310215. <br> Nicolás Gael Martínez Muños 302310208.</p>
    </footer>
    
    <script>
        let subMenu = document.getElementById("subMenu");
        function toggleMenu(){
            subMenu.classList.toggle("open-menu");
        }
    </script>
</body>
</html>
