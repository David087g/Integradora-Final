<?php
// Iniciar sesión
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el ID del usuario de la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener el nombre del usuario
$consulta = "SELECT usuario FROM iniciodesesion WHERE id = '$usuario_id'";
$resultado = mysqli_query($enlace, $consulta);

// Verificar si se encontró el usuario
if ($resultado && mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    $nombre_usuario = $usuario['usuario'];
} else {
    $nombre_usuario = "Usuario"; // Valor por defecto si no se encuentra el usuario
}

// Cerrar la conexión
mysqli_close($enlace);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="BienvenidoCssPhp.css">
    <title>Bienvenido</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav-left">
                <img class="logo" src="../Imagenes/Logo.PNG" alt="Logo">
                <a href="Pag1.html" class="inicio" style="color: black;">INICIO</a>
            </div>
            <ul class="nav-right">
            <li><a href="HuellasPerdidas.php"><span class="icon">&#x1F4CD;</span> HUELLAS PERDIDAS</a></li>
            <li><a href="SubirHuellas.php"><span class="icon">&#x1F4E9;</span>SUBIR HUELLAS</a></li>
            <li><a href="AceptarAdopciones.php"><span class="icon">&#x1F4D6;</span> ADOPTA</a></li>
            <li><a href="Bienvenido.php"><span class="icon">&#x1F4D6;</span> CODIGO DE ETICA</a></li>
                <!--<li><a href="CerrarSesion.php"><span class="icon">&#x1F511;</span> CERRAR SESION</a></li>-->
            </ul>
            <img src="../Imagenes/user.png" class="user-pic" onclick="toggleMenu()">

            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="../Imagenes/user.png" alt="">
                        <h2><?php echo htmlspecialchars($nombre_usuario); ?></h2>
                    </div>
                    <hr>
                    <a href="editarPerfil.php" class="sub-menu-link">
                        <img src="../Imagenes/profile.png" alt="">
                        <p>Editar perfil</p>
                        <span>></span>
                    </a>

                    <a href="CerrarSesion.php" class="sub-menu-link">
                        <img src="../Imagenes/logout.png" alt="">
                        <p>Cerrar Sesión</p>
                        <span>></span>
                    </a>
                </div>
            </div>
        </nav>
    </header>
    
    <script>
        let subMenu = document.getElementById("subMenu");
        function toggleMenu(){
            subMenu.classList.toggle("open-menu");
        }
    </script>
</body>
</html>
