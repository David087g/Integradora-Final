<?php 
echo "hola mundo"

/*onceptos de js hojas de estilo y php*/
?>
