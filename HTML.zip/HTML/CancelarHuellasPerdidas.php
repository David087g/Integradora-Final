<?php
// Iniciar sesión si no lo está ya
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$conn = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Verificar si es el día 21 para permitir la eliminación de huellas aprobadas
$dia_actual = date('d');
$permitido = ($dia_actual == 11);

// Verificar si se ha enviado el formulario para eliminar todas las huellas aprobadas
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['eliminar_todas_aprobadas'])) {
    // Si no es día 21, mostrar alerta y no procesar la eliminación
    if (!$permitido) {
        echo "<script type='text/javascript'>
                alert('Solo puedes eliminar todas las huellas aprobadas el día 21 de cada mes.');
                window.location.href = 'cancelarhuellasperdidas.php';
              </script>";
        exit; // Salir del script
    }

    // Consultar las huellas aprobadas
    $consulta_aprobadas = "SELECT * FROM subirhuellasperdidas WHERE aprobado = 1";
    $resultado_aprobadas = mysqli_query($conn, $consulta_aprobadas);

    // Mover las huellas a la tabla HuellasEliminadas
    mysqli_begin_transaction($conn); // Iniciar transacción

    try {
        // Preparar la consulta de inserción en HuellasEliminadas
        $query_insertar = "INSERT INTO HuellasEliminadas (nombre, raza, color, lugar, contacto, foto) 
                           VALUES (?, ?, ?, ?, ?, ?)";

        // Preparar la declaración
        $stmt = mysqli_prepare($conn, $query_insertar);
        if (!$stmt) {
            throw new Exception("Error al preparar la consulta de inserción: " . mysqli_error($conn));
        }

        // Vincular parámetros
        mysqli_stmt_bind_param($stmt, "sssssb", $nombre, $raza, $color, $lugar, $contacto, $foto);

        // Recorrer cada huella aprobada y ejecutar la inserción
        while ($huella = mysqli_fetch_assoc($resultado_aprobadas)) {
            // Obtener datos de la huella perdida
            $nombre = $huella['nombre'];
            $raza = $huella['raza'];
            $color = $huella['color'];
            $lugar = $huella['lugar'];
            $contacto = $huella['contacto'];
            $foto = $huella['foto'];

            // Ejecutar la declaración preparada
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Error al ejecutar la consulta de inserción: " . mysqli_stmt_error($stmt));
            }
        }

        // Confirmar la transacción
        mysqli_commit($conn);

        // Borrar las huellas aprobadas de subirhuellasperdidas
        $query_borrar_aprobadas = "DELETE FROM subirhuellasperdidas WHERE aprobado = 1";

        if (mysqli_query($conn, $query_borrar_aprobadas)) {
            echo "<script type='text/javascript'>
                    alert('Todas las huellas perdidas aprobadas han sido eliminadas y movidas a HuellasEliminadas.');
                    window.location.href = 'cancelarhuellasperdidas.php';
                  </script>";
        } else {
            throw new Exception("Error al borrar huellas perdidas aprobadas: " . mysqli_error($conn));
        }
    } catch (Exception $e) {
        // Revertir la transacción si hay algún error
        mysqli_rollback($conn);
        echo "Error: " . $e->getMessage();
    } finally {
        // Cerrar la declaración preparada
        if (isset($stmt)) {
            mysqli_stmt_close($stmt);
        }
    }
}

?>





<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cancelar Huellas Perdidas</title>
    <link rel="stylesheet" href="AceptarHuellas.css">
</head>
<body>

<header>
    <nav>
        <div class="nav-left">
            <img class="logo" src="../Imagenes/Logo.PNG" alt="Logo">
            <a href="ADMIN.php" class="inicio" style="color: white;">INICIO</a>
        </div>
        <ul class="nav-right">
            <li><a href="AceptarHuellas.php"><span class="icon">&#x1F4E9;</span> ACEPTAR HUELLAS</a></li>
            <li><a href="CancelarHuellasPerdidas.php"><span class="icon">&#x1F4E9;</span> CANCELAR HUELLAS</a></li>
            <li><a href="ADMIN.php"><span class="icon">&#x1F4D6;</span> CODIGO DE ETICA</a></li>
        </ul>
        <img src="../Imagenes/David.jpg" class="user-pic" onclick="toggleMenu()">

        <div class="sub-menu-wrap" id="subMenu">
            <div class="sub-menu">
                <div class="user-info">
                    <img src="../Imagenes/David.jpg" alt="">
                    <h2>ADMIN</h2>
                </div>
                <hr>
                

                <a href="CerrarSesion.php" class="sub-menu-link">
                    <img src="../Imagenes/logout.png" alt="">
                    <p>Cerrar Sesión</p>
                    <span>></span>
                </a>
            </div>
        </div>
    </nav>
</header>

<div class="contenedor-huellas">
    <h1>Cancelar Huellas Perdidas</h1>

    <form action="cancelarhuellasperdidas.php" method="POST">
    <?php
    // Obtener el día actual del mes
    $dia_actual = date('d');
    
    // Verificar si es día 21 y si está permitido eliminar
    if ($dia_actual == 11 && $permitido): ?>
        <input type="submit" name="eliminar_todas_aprobadas" value="Eliminar todas las aprobadas" class="borrar">
    <?php else: ?>
        <button type="button" class="borrar" disabled>
            <?php if ($dia_actual == 11): ?>
                Eliminar todas las aprobadas
            <?php else: ?>
                Eliminar todas las aprobadas (Solo el día 21)
            <?php endif; ?>
        </button>
    <?php endif; ?>
</form>


    <?php
    // Consulta para obtener todas las huellas perdidas aprobadas
    $consulta_huellas = "SELECT * FROM subirhuellasperdidas WHERE aprobado = 1";
    $resultado_huellas = mysqli_query($conn, $consulta_huellas);

    if (mysqli_num_rows($resultado_huellas) > 0) {
        while ($huella = mysqli_fetch_assoc($resultado_huellas)) {
            echo "<div class='tarjeta'>";
            echo "<div class='campo'>";
            echo "<span class='titulo'>⬇Nombre⬇</span>";
            echo "<span class='valor'>" . $huella['nombre'] . "</span>";
            echo "</div>";
            echo "<div class='campo'>";
            echo "<span class='titulo'>⬇Raza⬇</span>";
            echo "<span class='valor'>" . $huella['raza'] . "</span>";
            echo "</div>";
            echo "<div class='campo'>";
            echo "<span class='titulo'>⬇Color⬇</span>";
            echo "<span class='valor'>" . $huella['color'] . "</span>";
            echo "</div>";
            echo "<div class='campo'>";
            echo "<span class='titulo'>⬇Ultimo Lugar Visto⬇</span>";
            echo "<span class='valor'>" . $huella['lugar'] . "</span>";
            echo "</div>";
            echo "<div class='campo'>";
            echo "<span class='titulo'>⬇Contacto⬇</span>";
            echo "<span class='valor'>" . $huella['contacto'] . "</span>";
            echo "</div>";

            // Otros detalles de la huella perdida...
            echo "<div class='campo'>";
            echo "<span class='titulo'>Foto:</span>";
            echo "<div class='foto' onclick='openModal(\"data:image/jpeg;base64," . base64_encode($huella['foto']) . "\")'>";
            echo "<img src='data:image/jpeg;base64," . base64_encode($huella['foto']) . "' alt='Foto de la mascota'>";
            echo "<p>Foto</p>"; // Texto para centrar junto a la foto
            echo "</div>";
            echo "</div>";

            // Formulario para borrar la huella perdida
            echo "<form action='Eliminar_una_Huella.php' method='POST'>";
            echo "<input type='hidden' name='huella_id' value='" . $huella['id'] . "'>";
            echo "<input type='submit' value='Borrar' class='borrar'>";
            echo "</form>";

            echo "</div>"; // Cerrar tarjeta
        }
    } else {
        echo "<p>No hay huellas perdidas aprobadas registradas.</p>";
    }
    ?>
</div>
<footer id="pie">
    <p>&copy; 2024 Alonso Flores David Abraham. Matricula 302310215.</p>
</footer>

<script>
    let subMenu = document.getElementById("subMenu");
    function toggleMenu() {
        subMenu.classList.toggle("open-menu");
    }
</script>

</body>
</html>
<?php 
// Cerrar la conexión a la base de datos
mysqli_close($conn);
?>
