<?php
// Iniciar sesión
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir al inicio de sesión si no hay sesión activa
    header("Location: inicioSeccion1.html");
    exit;
}

// Conexión a la base de datos
$Servidor = "localhost";
$Usuario = "root";
$Contraseña = "";
$BaseDeDatos = "integradora";

$enlace = mysqli_connect($Servidor, $Usuario, $Contraseña, $BaseDeDatos);

// Verificar si la conexión fue exitosa
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el ID del usuario de la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener el nombre del usuario
$consulta = "SELECT usuario FROM iniciodesesion WHERE id = '$usuario_id'";
$resultado = mysqli_query($enlace, $consulta);

// Verificar si se encontró el usuario
if ($resultado && mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    $nombre_usuario = $usuario['usuario'];
} else {
    $nombre_usuario = "Usuario"; // Valor por defecto si no se encuentra el usuario
}

// Consulta para obtener las huellas perdidas que necesitan ser aprobadas o canceladas
$consulta_huellas = "SELECT * FROM subirhuellasperdidas WHERE aprobado = 0";
$resultado_huellas = mysqli_query($enlace, $consulta_huellas);


?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aceptar Huellas</title>
    <link rel="stylesheet" href="AceptarHuellas.css">
</head>
<body>

<header>
    <nav>
    <div class="nav-left">
            <img class="logo" src="../Imagenes/Logo.PNG" alt="Logo">
            <a href="Admin.php" class="inicio" style="color: white;">INICIO</a>
        </div>
        <ul class="nav-right">
        <li><a href="AceptarHuellas.php"><span class="icon">&#x1F4E9;</span> ACEPTAR HUELLAS</a></li>
            <li><a href="CancelarHuellasPerdidas.php"><span class="icon">&#x1F4E9;</span> CANCELAR HUELLAS</a></li>
            <li><a href="ADMIN.php"><span class="icon">&#x1F4D6;</span> CODIGO DE ETICA</a></li>
            <!--<li><a href="CerrarSesion.php"><span class="icon">&#x1F511;</span> CERRAR SESION</a></li>-->
        </ul>
        <img src="../Imagenes/David.jpg" class="user-pic" onclick="toggleMenu()">

        <div class="sub-menu-wrap" id="subMenu">
            <div class="sub-menu">
                <div class="user-info">
                    <img src="../Imagenes/David.jpg" alt="">
                    <h2>ADMIN</h2>
                </div>
                <hr>
                

                <a href="CerrarSesion.php" class="sub-menu-link">
                    <img src="../Imagenes/logout.png" alt="">
                    <p>Cerrar Sesión</p>
                    <span>></span>
                </a>
            </div>
        </div>
    </nav>
</header>
<br><br><br><br><br>
<main>
    <div class="contenedor-huellas">
        <?php
        if (mysqli_num_rows($resultado_huellas) > 0) {
            while ($huella = mysqli_fetch_assoc($resultado_huellas)) {
                echo "<div class='tarjeta'>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Nombre⬇</span>";
                echo "<span class='valor'>" . $huella['nombre'] . "</span>";
                echo "</div>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Raza⬇</span>";
                echo "<span class='valor'>" . $huella['raza'] . "</span>";
                echo "</div>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Color⬇</span>";
                echo "<span class='valor'>" . $huella['color'] . "</span>";
                echo "</div>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Ultimo Lugar Visto⬇</span>";
                echo "<span class='valor'>" . $huella['lugar'] . "</span>";
                echo "</div>";
                echo "<div class='campo'>";
                echo "<span class='titulo'>⬇Contacto⬇</span>";
                echo "<span class='valor'>" . $huella['contacto'] . "</span>";
                echo "</div>";
                // Otros detalles de la huella perdida...
                echo "<div class='campo'>";
                echo "<span class='titulo'>Foto:</span>";
                echo "<div class='foto' onclick='openModal(\"data:image/jpeg;base64," . base64_encode($huella['foto']) . "\")'>";
                echo "<img src='data:image/jpeg;base64," . base64_encode($huella['foto']) . "' alt='Foto de la mascota'>";
                echo "<p>Foto</p>"; // Texto para centrar junto a la foto
                echo "</div>";
                echo "</div>";
                // Formulario para aprobar la huella perdida
                echo "<form action='HuellasPerdidas.php' method='POST'>";
                echo "<input type='hidden' name='huella_id' value='" . $huella['id'] . "'>";
                echo "<input type='submit' value='Aprobar'>";
                echo "</form>";

                // Formulario para cancelar la huella perdida
                echo "<form action='CancelarHuella.php' method='POST'>";
                echo "<input type='hidden' name='huella_id' value='" . $huella['id'] . "'>";
                echo "<input type='submit' value='Cancelar' class='cancelar'>";
                echo "</form>";

                echo "</div>";
            }
        } else {
            echo "<p>No hay huellas perdidas por revisar.</p>";
        }
        ?>
    </div>
</main>
<footer id="pie">
        <p>&copy; 2024 Alonso Flores David Abraham. Matricula 302310215.</p>
    </footer>
<!-- Modal para mostrar la imagen en grande -->
<div id="myModal" class="modal">
  <span class="close" onclick="closeModal()">&times;</span>
 
  <img class="modal-content" id="modalImg">
</div>

<script>
    let subMenu = document.getElementById("subMenu");
    function toggleMenu(){
        subMenu.classList.toggle("open-menu");
    }

    // Función para abrir el modal con la imagen en grande
    function openModal(imageSrc) {
        var modal = document.getElementById("myModal");
        var modalImg = document.getElementById("modalImg");
        modal.style.display = "block";
        modalImg.src = imageSrc;
    }

    // Función para cerrar el modal
    function closeModal() {
        var modal = document.getElementById("myModal");
        modal.style.display = "none";
    }
</script>


</body>
</html>

<?php
// Cerrar la conexión a la base de datos
mysqli_close($enlace);
?>